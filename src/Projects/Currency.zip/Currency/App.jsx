import React from 'react';
import Currency from './Currency';

const App = () => {
  return (<>
    <Currency />
  </>)
}

export default App;